<?php


namespace Okay\Core;


use Okay\Core\Modules\Modules;
use Okay\Entities\TranslationsEntity;

class FrontTranslations
{
    
    private $_debugTranslation;
    private $_entityFactory;
    private $_languages;
    private $_modules;
    private $_translations;
    
    public function __construct(EntityFactory $entityFactory, Languages $languages, Modules $modules, $debugTranslation = false)
    {
        $this->_debugTranslation = (bool)$debugTranslation;
        $this->_entityFactory = $entityFactory;
        $this->_languages = $languages;
        $this->_modules = $modules;
        
        $this->init();
    }

    public function init()
    {
        $langLabel = $this->_languages->getLangLabel();

        /** @var TranslationsEntity $translations */
        $translations = $this->_entityFactory->get(TranslationsEntity::class);
        foreach ($translations->find(['lang' => $langLabel]) as $var => $translation) {
            $this->_translations[$var] = $translation->value;
        }
    }
    
    public function __get($var)
    {
        if (isset($this->_translations[$var])) {
            return $this->_translations[$var];
        }

        // Если не нашли перевода на текущем языке, посмотрим может есть этот перевод на основном языке или уже на английском
        /** @var TranslationsEntity $translations */
        $translations = $this->_entityFactory->get(TranslationsEntity::class);
        $mainLanguage = $this->_languages->getMainLanguage();
        $res = $translations->get($var);
        if (isset($res->{'lang_' . $mainLanguage->label}) || isset($res->lang_en)) {
            if (isset($res->{'lang_' . $mainLanguage->label})) {
                $translation = $res->{'lang_' . $mainLanguage->label}->value;
            } else {
                $translation = $res->lang_en->value;
            }

            $this->_translations[$var] = $translation;

            // Если включили дебаг переводов, выведим соответствующее сообщение на неизвестный перевод
            if ($this->_debugTranslation === true) {
                $translation .= '<b style="color: red!important;">$lang->' . $var . ' from other language</b>';
            }
            return $translation;
        } elseif ($this->_debugTranslation === true) {
            return '<b style="color: red!important;">$lang->' . $var . ' not exists</b>';
        }
    }
    
    public function getTranslation($var)
    {
        return $this->_translations[$var];
    }
    
    public function addTranslation($var, $translation)
    {
        $var = preg_replace('~[^\w]~', '', (string) $var);
        $this->_translations[$var] = $translation;
    }
}
